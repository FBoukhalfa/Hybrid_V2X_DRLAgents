import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import gym
import matplotlib.pyplot as plt
import copy

################################## set device ##################################
print("============================================================================================")
# set device to cpu or cuda
device = torch.device('cpu')
if(torch.cuda.is_available()): 
    device = torch.device('cuda:0') 
    torch.cuda.empty_cache()
    print("Device set to : " + str(torch.cuda.get_device_name(device)))
else:
    print("Device set to : cpu")
print("============================================================================================")


class Net(nn.Module):
    """docstring for Net"""
    def __init__(self, NUM_STATES, NUM_ACTIONS):
        super(Net, self).__init__()
        
        
        """ self.fc1 = nn.Linear(NUM_STATES, 50)
        self.fc1.weight.data.normal_(0,0.1)
        self.fc2 = nn.Linear(50,30)
        self.fc2.weight.data.normal_(0,0.1)
        self.out = nn.Linear(30,NUM_ACTIONS)
        self.out.weight.data.normal_(0,0.1) """
        
        self.fc1 = nn.Linear(NUM_STATES, 120)
        self.fc1.weight.data.normal_(0,0.1)
        self.fc2 = nn.Linear(120,84) 
        self.fc2.weight.data.normal_(0,0.1)
        self.out = nn.Linear(84,NUM_ACTIONS)
        self.out.weight.data.normal_(0,0.1)
        

    def forward(self,x):
        x = self.fc1(x)
        x = F.relu(x)
        x = self.fc2(x)
        x = F.relu(x)
        action_prob = self.out(x)
        return action_prob

class DQN():
    """docstring for DQN"""
    def __init__(self, env, BATCH_SIZE, LR, GAMMA, EPISILO, MEMORY_CAPACITY, Q_NETWORK_ITERATION):
        super(DQN, self).__init__()
        self.env = env
        self.BATCH_SIZE = BATCH_SIZE
        self.LR = LR
        self.GAMMA = GAMMA
        self.EPISILO = EPISILO
        self.MEMORY_CAPACITY = MEMORY_CAPACITY
        self.Q_NETWORK_ITERATION = Q_NETWORK_ITERATION
		
        self.NUM_ACTIONS = 8
        self.NUM_STATES = 4
        self.ENV_A_SHAPE = 0 
		
        self.eval_net, self.target_net = Net(self.NUM_STATES, self.NUM_ACTIONS), Net(self.NUM_STATES, self.NUM_ACTIONS)

        self.learn_step_counter = 0
        self.memory_counter = 0
        self.memory = np.zeros((self.MEMORY_CAPACITY, self.NUM_STATES * 2 + 2))
        # why the NUM_STATE*2 +2
        # When we store the memory, we put the state, action, reward and next_state in the memory
        # here reward and action is a number, state is a ndarray
        self.optimizer = torch.optim.Adam(self.eval_net.parameters(), lr=self.LR)
        self.loss_func = nn.MSELoss()
        self.t = 0

    def choose_action(self, state, test):
        state = torch.unsqueeze(torch.FloatTensor(state), 0) # get a 1D array
        #start_e, end_e, duration = 1, 0.05, 2000*4000*0.5
        #if not test:
        #    self.EPISILO = self.linear_schedule(start_e, end_e, duration, self.t)
        self.t += 1
        if np.random.randn() <=  self.EPISILO:# greedy policy
            action = np.random.randint(0, self.NUM_ACTIONS)
            action = action if self.ENV_A_SHAPE ==0 else action.reshape(self.ENV_A_SHAPE)
        else:# greedy policy
            action_value = self.eval_net.forward(state)
            action = torch.max(action_value, 1)[1].data.numpy()
            action = action[0] if self.ENV_A_SHAPE == 0 else action.reshape(self.ENV_A_SHAPE)
        return action


    def store_transition(self, state, action, reward, next_state):
        transition = np.hstack((state, [action, reward], next_state))
        index = self.memory_counter % self.MEMORY_CAPACITY
        self.memory[index, :] = transition
        self.memory_counter += 1

    def linear_schedule(self, start_e, end_e, duration, t):
        slope = (end_e - start_e) / duration
        return max(slope * t + start_e, end_e)

    def learn(self):

        #update the parameters
        if self.learn_step_counter % self.Q_NETWORK_ITERATION ==0:
            self.target_net.load_state_dict(self.eval_net.state_dict())
        self.learn_step_counter+=1

        #sample batch from memory
        sample_index = np.random.choice(self.MEMORY_CAPACITY, self.BATCH_SIZE)
        batch_memory = self.memory[sample_index, :]
        batch_state = torch.FloatTensor(batch_memory[:, :self.NUM_STATES])
        batch_action = torch.LongTensor(batch_memory[:, self.NUM_STATES:self.NUM_STATES+1].astype(int))
        batch_reward = torch.FloatTensor(batch_memory[:, self.NUM_STATES+1:self.NUM_STATES+2])
        batch_next_state = torch.FloatTensor(batch_memory[:,-self.NUM_STATES:])

        #q_eval
        q_eval = self.eval_net(batch_state).gather(1, batch_action)
        q_next = self.target_net(batch_next_state).detach()
        q_target = batch_reward + self.GAMMA * q_next.max(1)[0].view(self.BATCH_SIZE, 1)
        loss = self.loss_func(q_eval, q_target)

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
		
		
		
    def save(self, checkpoint_path):
        torch.save(self.eval_net.state_dict(), checkpoint_path)
   
    def load(self, checkpoint_path):
        self.eval_net.load_state_dict(torch.load(checkpoint_path, map_location=lambda storage, loc: storage))
        



